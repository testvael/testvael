var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "1274502",
        "ok": "1130479",
        "ko": "144023"
    },
    "minResponseTime": {
        "total": "10",
        "ok": "10",
        "ko": "10"
    },
    "maxResponseTime": {
        "total": "600014",
        "ok": "29993",
        "ko": "600014"
    },
    "meanResponseTime": {
        "total": "3378",
        "ok": "2578",
        "ko": "9660"
    },
    "standardDeviation": {
        "total": "9077",
        "ok": "3933",
        "ko": "23733"
    },
    "percentiles1": {
        "total": "1165",
        "ok": "974",
        "ko": "7866"
    },
    "percentiles2": {
        "total": "4409",
        "ok": "3299",
        "ko": "13868"
    },
    "percentiles3": {
        "total": "13926",
        "ok": "11207",
        "ko": "22414"
    },
    "percentiles4": {
        "total": "21680",
        "ok": "17664",
        "ko": "30013"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 540518,
        "percentage": 42
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 73885,
        "percentage": 6
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 516076,
        "percentage": 40
    },
    "group4": {
        "name": "failed",
        "count": 144023,
        "percentage": 11
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "85.075",
        "ok": "75.461",
        "ko": "9.614"
    }
},
contents: {
"req_set-headers-a44e1": {
        type: "REQUEST",
        name: "set_headers",
path: "set_headers",
pathFormatted: "req_set-headers-a44e1",
stats: {
    "name": "set_headers",
    "numberOfRequests": {
        "total": "144000",
        "ok": "140965",
        "ko": "3035"
    },
    "minResponseTime": {
        "total": "48",
        "ok": "48",
        "ko": "51"
    },
    "maxResponseTime": {
        "total": "600014",
        "ok": "9718",
        "ko": "600014"
    },
    "meanResponseTime": {
        "total": "1201",
        "ok": "110",
        "ko": "51877"
    },
    "standardDeviation": {
        "total": "22707",
        "ok": "383",
        "ko": "147759"
    },
    "percentiles1": {
        "total": "58",
        "ok": "58",
        "ko": "10005"
    },
    "percentiles2": {
        "total": "67",
        "ok": "66",
        "ko": "10009"
    },
    "percentiles3": {
        "total": "223",
        "ok": "107",
        "ko": "579420"
    },
    "percentiles4": {
        "total": "10005",
        "ok": "1675",
        "ko": "600002"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 138523,
        "percentage": 96
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 582,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1860,
        "percentage": 1
    },
    "group4": {
        "name": "failed",
        "count": 3035,
        "percentage": 2
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "9.612",
        "ok": "9.41",
        "ko": "0.203"
    }
}
    },"req_register-device-bdc58": {
        type: "REQUEST",
        name: "register_device",
path: "register_device",
pathFormatted: "req_register-device-bdc58",
stats: {
    "name": "register_device",
    "numberOfRequests": {
        "total": "140965",
        "ok": "138383",
        "ko": "2582"
    },
    "minResponseTime": {
        "total": "25",
        "ok": "25",
        "ko": "549"
    },
    "maxResponseTime": {
        "total": "12468",
        "ok": "8854",
        "ko": "12468"
    },
    "meanResponseTime": {
        "total": "1452",
        "ok": "1384",
        "ko": "5122"
    },
    "standardDeviation": {
        "total": "1307",
        "ok": "1216",
        "ko": "566"
    },
    "percentiles1": {
        "total": "1211",
        "ok": "1182",
        "ko": "5034"
    },
    "percentiles2": {
        "total": "2194",
        "ok": "2125",
        "ko": "5045"
    },
    "percentiles3": {
        "total": "4116",
        "ok": "3784",
        "ko": "5246"
    },
    "percentiles4": {
        "total": "5037",
        "ok": "4742",
        "ko": "7222"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 52180,
        "percentage": 37
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 17849,
        "percentage": 13
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 68354,
        "percentage": 48
    },
    "group4": {
        "name": "failed",
        "count": 2582,
        "percentage": 2
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "9.41",
        "ok": "9.237",
        "ko": "0.172"
    }
}
    },"req_register-user-0a263": {
        type: "REQUEST",
        name: "register_user",
path: "register_user",
pathFormatted: "req_register-user-0a263",
stats: {
    "name": "register_user",
    "numberOfRequests": {
        "total": "138383",
        "ok": "130585",
        "ko": "7798"
    },
    "minResponseTime": {
        "total": "38",
        "ok": "114",
        "ko": "38"
    },
    "maxResponseTime": {
        "total": "23929",
        "ok": "23181",
        "ko": "23929"
    },
    "meanResponseTime": {
        "total": "5554",
        "ok": "5370",
        "ko": "8634"
    },
    "standardDeviation": {
        "total": "4143",
        "ok": "4119",
        "ko": "3230"
    },
    "percentiles1": {
        "total": "5654",
        "ok": "5497",
        "ko": "8242"
    },
    "percentiles2": {
        "total": "8557",
        "ok": "8387",
        "ko": "10771"
    },
    "percentiles3": {
        "total": "12446",
        "ok": "12254",
        "ko": "14578"
    },
    "percentiles4": {
        "total": "15242",
        "ok": "14992",
        "ko": "17502"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 33836,
        "percentage": 24
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1064,
        "percentage": 1
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 95685,
        "percentage": 69
    },
    "group4": {
        "name": "failed",
        "count": 7798,
        "percentage": 6
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "9.237",
        "ok": "8.717",
        "ko": "0.521"
    }
}
    },"req_check-email-sta-ebc5b": {
        type: "REQUEST",
        name: "check_email_status",
path: "check_email_status",
pathFormatted: "req_check-email-sta-ebc5b",
stats: {
    "name": "check_email_status",
    "numberOfRequests": {
        "total": "140965",
        "ok": "131307",
        "ko": "9658"
    },
    "minResponseTime": {
        "total": "29",
        "ok": "29",
        "ko": "45"
    },
    "maxResponseTime": {
        "total": "12435",
        "ok": "8334",
        "ko": "12435"
    },
    "meanResponseTime": {
        "total": "1359",
        "ok": "1259",
        "ko": "2709"
    },
    "standardDeviation": {
        "total": "1256",
        "ok": "1163",
        "ko": "1633"
    },
    "percentiles1": {
        "total": "1095",
        "ok": "1027",
        "ko": "2304"
    },
    "percentiles2": {
        "total": "2042",
        "ok": "1933",
        "ko": "4337"
    },
    "percentiles3": {
        "total": "3909",
        "ok": "3580",
        "ko": "5048"
    },
    "percentiles4": {
        "total": "5032",
        "ok": "4667",
        "ko": "5629"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 55285,
        "percentage": 39
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 18018,
        "percentage": 13
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 58004,
        "percentage": 41
    },
    "group4": {
        "name": "failed",
        "count": 9658,
        "percentage": 7
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "9.41",
        "ok": "8.765",
        "ko": "0.645"
    }
}
    },"req_verify-email-31505": {
        type: "REQUEST",
        name: "verify_email",
path: "verify_email",
pathFormatted: "req_verify-email-31505",
stats: {
    "name": "verify_email",
    "numberOfRequests": {
        "total": "131307",
        "ok": "128521",
        "ko": "2786"
    },
    "minResponseTime": {
        "total": "35",
        "ok": "35",
        "ko": "5029"
    },
    "maxResponseTime": {
        "total": "13702",
        "ok": "10094",
        "ko": "13702"
    },
    "meanResponseTime": {
        "total": "1990",
        "ok": "1908",
        "ko": "5754"
    },
    "standardDeviation": {
        "total": "1837",
        "ok": "1761",
        "ko": "1204"
    },
    "percentiles1": {
        "total": "1616",
        "ok": "1561",
        "ko": "5050"
    },
    "percentiles2": {
        "total": "3130",
        "ok": "3008",
        "ko": "6273"
    },
    "percentiles3": {
        "total": "5443",
        "ok": "5282",
        "ko": "8299"
    },
    "percentiles4": {
        "total": "7143",
        "ok": "6911",
        "ko": "9685"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 44305,
        "percentage": 34
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 10446,
        "percentage": 8
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 73770,
        "percentage": 56
    },
    "group4": {
        "name": "failed",
        "count": 2786,
        "percentage": 2
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "8.765",
        "ok": "8.579",
        "ko": "0.186"
    }
}
    },"req_associate-verif-615f6": {
        type: "REQUEST",
        name: "associate_verification_code_with_email",
path: "associate_verification_code_with_email",
pathFormatted: "req_associate-verif-615f6",
stats: {
    "name": "associate_verification_code_with_email",
    "numberOfRequests": {
        "total": "138383",
        "ok": "127354",
        "ko": "11029"
    },
    "minResponseTime": {
        "total": "54",
        "ok": "60",
        "ko": "54"
    },
    "maxResponseTime": {
        "total": "13196",
        "ok": "10236",
        "ko": "13196"
    },
    "meanResponseTime": {
        "total": "2334",
        "ok": "2274",
        "ko": "3021"
    },
    "standardDeviation": {
        "total": "1952",
        "ok": "1915",
        "ko": "2225"
    },
    "percentiles1": {
        "total": "2096",
        "ok": "2083",
        "ko": "2242"
    },
    "percentiles2": {
        "total": "3646",
        "ok": "3583",
        "ko": "5036"
    },
    "percentiles3": {
        "total": "5895",
        "ok": "5768",
        "ko": "7199"
    },
    "percentiles4": {
        "total": "7487",
        "ok": "7231",
        "ko": "8921"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 38871,
        "percentage": 28
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 6219,
        "percentage": 4
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 82264,
        "percentage": 59
    },
    "group4": {
        "name": "failed",
        "count": 11029,
        "percentage": 8
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "9.237",
        "ok": "8.501",
        "ko": "0.736"
    }
}
    },"req_register-phone-1d15c": {
        type: "REQUEST",
        name: "register_phone",
path: "register_phone",
pathFormatted: "req_register-phone-1d15c",
stats: {
    "name": "register_phone",
    "numberOfRequests": {
        "total": "130585",
        "ok": "116403",
        "ko": "14182"
    },
    "minResponseTime": {
        "total": "34",
        "ok": "139",
        "ko": "34"
    },
    "maxResponseTime": {
        "total": "28719",
        "ok": "28719",
        "ko": "28523"
    },
    "meanResponseTime": {
        "total": "7014",
        "ok": "7007",
        "ko": "7076"
    },
    "standardDeviation": {
        "total": "5437",
        "ok": "5489",
        "ko": "4990"
    },
    "percentiles1": {
        "total": "7297",
        "ok": "7406",
        "ko": "6387"
    },
    "percentiles2": {
        "total": "11139",
        "ok": "11196",
        "ko": "10561"
    },
    "percentiles3": {
        "total": "15943",
        "ok": "15924",
        "ko": "16115"
    },
    "percentiles4": {
        "total": "19210",
        "ok": "19162",
        "ko": "19689"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 32430,
        "percentage": 25
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1065,
        "percentage": 1
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 82908,
        "percentage": 63
    },
    "group4": {
        "name": "failed",
        "count": 14182,
        "percentage": 11
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "8.717",
        "ok": "7.77",
        "ko": "0.947"
    }
}
    },"req_get-otp-code-da753": {
        type: "REQUEST",
        name: "get_otp_code",
path: "get_otp_code",
pathFormatted: "req_get-otp-code-da753",
stats: {
    "name": "get_otp_code",
    "numberOfRequests": {
        "total": "144000",
        "ok": "118600",
        "ko": "25400"
    },
    "minResponseTime": {
        "total": "10",
        "ok": "10",
        "ko": "10"
    },
    "maxResponseTime": {
        "total": "600002",
        "ok": "3086",
        "ko": "600002"
    },
    "meanResponseTime": {
        "total": "48",
        "ok": "28",
        "ko": "143"
    },
    "standardDeviation": {
        "total": "3171",
        "ok": "122",
        "ko": "7545"
    },
    "percentiles1": {
        "total": "14",
        "ok": "14",
        "ko": "14"
    },
    "percentiles2": {
        "total": "16",
        "ok": "16",
        "ko": "18"
    },
    "percentiles3": {
        "total": "34",
        "ok": "28",
        "ko": "57"
    },
    "percentiles4": {
        "total": "362",
        "ok": "349",
        "ko": "408"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 117846,
        "percentage": 82
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 103,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 651,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 25400,
        "percentage": 18
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "9.612",
        "ok": "7.917",
        "ko": "1.695"
    }
}
    },"req_verify-phone-nu-99e4e": {
        type: "REQUEST",
        name: "verify_phone_number",
path: "verify_phone_number",
pathFormatted: "req_verify-phone-nu-99e4e",
stats: {
    "name": "verify_phone_number",
    "numberOfRequests": {
        "total": "116403",
        "ok": "49695",
        "ko": "66708"
    },
    "minResponseTime": {
        "total": "203",
        "ok": "203",
        "ko": "552"
    },
    "maxResponseTime": {
        "total": "31086",
        "ok": "29993",
        "ko": "31086"
    },
    "meanResponseTime": {
        "total": "10997",
        "ok": "6347",
        "ko": "14462"
    },
    "standardDeviation": {
        "total": "8269",
        "ok": "8525",
        "ko": "6087"
    },
    "percentiles1": {
        "total": "11338",
        "ok": "577",
        "ko": "13830"
    },
    "percentiles2": {
        "total": "17041",
        "ok": "13184",
        "ko": "18092"
    },
    "percentiles3": {
        "total": "24991",
        "ok": "23491",
        "ko": "26590"
    },
    "percentiles4": {
        "total": "30013",
        "ok": "27390",
        "ko": "30014"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 27241,
        "percentage": 23
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1680,
        "percentage": 1
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 20774,
        "percentage": 18
    },
    "group4": {
        "name": "failed",
        "count": 66708,
        "percentage": 57
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "7.77",
        "ok": "3.317",
        "ko": "4.453"
    }
}
    },"req_register-passwo-f736a": {
        type: "REQUEST",
        name: "register_password",
path: "register_password",
pathFormatted: "req_register-passwo-f736a",
stats: {
    "name": "register_password",
    "numberOfRequests": {
        "total": "49511",
        "ok": "48666",
        "ko": "845"
    },
    "minResponseTime": {
        "total": "420",
        "ok": "420",
        "ko": "2506"
    },
    "maxResponseTime": {
        "total": "29911",
        "ok": "29911",
        "ko": "28861"
    },
    "meanResponseTime": {
        "total": "3652",
        "ok": "3528",
        "ko": "10823"
    },
    "standardDeviation": {
        "total": "3948",
        "ok": "3813",
        "ko": "4872"
    },
    "percentiles1": {
        "total": "1325",
        "ok": "1315",
        "ko": "9959"
    },
    "percentiles2": {
        "total": "5913",
        "ok": "5535",
        "ko": "12938"
    },
    "percentiles3": {
        "total": "11732",
        "ok": "11488",
        "ko": "20841"
    },
    "percentiles4": {
        "total": "15926",
        "ok": "15247",
        "ko": "26422"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 16859,
        "percentage": 34
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 31806,
        "percentage": 64
    },
    "group4": {
        "name": "failed",
        "count": 845,
        "percentage": 2
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "3.305",
        "ok": "3.249",
        "ko": "0.056"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
